using System.ComponentModel.DataAnnotations;

namespace EazzyTravels.Models
{
    // ---------- Lookup lists used to populate dropdowns / radios / checkboxes ----------
    public static class Lookups
    {
        public static readonly string[] Locations =
        {
            "Johannesburg", "Cape Town", "Durban", "Pretoria",
            "Port Elizabeth", "Bloemfontein", "Nelspruit", "Polokwane"
        };

        public static readonly string[] PlaneTypes =
        {
            "Boeing 737", "Airbus A320", "Regional Jet", "Cargo Plane", "Private Charter"
        };

        public static readonly string[] TicketClasses =
        {
            "Economy", "Business", "First Class"
        };

        public static readonly string[] InsuranceOptions =
        {
            "Comprehensive Cover", "Third-Party Cover", "No Insurance"
        };

        public static readonly string[] TransportTypes =
        {
            "Shuttle Bus", "Private Car", "Coach", "Rideshare", "Train"
        };

        public static readonly string[] HotelServices =
        {
            "Pool", "Spa", "Wi-Fi", "Gym", "Restaurant", "Parking", "Pet-friendly", "Airport Shuttle"
        };

        public static readonly string[] HotelTypes =
        {
            "Resort", "Boutique Hotel", "Guesthouse", "Lodge", "Budget Hotel", "5-Star Hotel"
        };

        public static readonly string[] EntertainmentTypes =
        {
            "Safari Tour", "Wine Tasting", "Museum Visit", "Beach Activities", "Hiking", "Cultural Show"
        };

        public static readonly string[] FoodOptions =
        {
            "Buffet", "A-la-carte", "Snacks Only", "No Food Provided"
        };

        public static readonly string[] SubscriptionTypes =
        {
            "Basic", "Standard", "Premium"
        };
    }

    public class Employee
    {
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        [StringLength(60, MinimumLength = 2, ErrorMessage = "First name must be 2-60 characters.")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last name is required.")]
        [StringLength(60, MinimumLength = 2, ErrorMessage = "Last name must be 2-60 characters.")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Role is required.")]
        public string Role { get; set; } = string.Empty;

        [Required(ErrorMessage = "Contact info is required.")]
        [RegularExpression(@"^[\w\.\-\+]+@[\w\-]+\.[a-zA-Z]{2,}$|^0\d{9}$",
            ErrorMessage = "Enter a valid email address or a 10-digit SA phone number (e.g. 0821234567).")]
        public string ContactInfo { get; set; } = string.Empty;

        [Range(1000, 1000000, ErrorMessage = "Salary must be between R1,000 and R1,000,000.")]
        public decimal Salary { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfHire { get; set; } = DateTime.Today;

        [Required]
        public string EmploymentStatus { get; set; } = "Full-time"; // Full-time / Part-time
    }

    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        [StringLength(60, MinimumLength = 2)]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last name is required.")]
        [StringLength(60, MinimumLength = 2)]
        public string LastName { get; set; } = string.Empty;

        [Range(18, 120, ErrorMessage = "Customers must be 18 or older.")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Contact info is required.")]
        [RegularExpression(@"^[\w\.\-\+]+@[\w\-]+\.[a-zA-Z]{2,}$|^0\d{9}$",
            ErrorMessage = "Enter a valid email address or a 10-digit SA phone number (e.g. 0821234567).")]
        public string ContactInfo { get; set; } = string.Empty;

        [Required]
        public string MaritalStatus { get; set; } = "Single";
    }

    public class Subscription
    {
        public int SubscriptionId { get; set; }

        [Required(ErrorMessage = "Please select a customer.")]
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "Please select a subscription type.")]
        public string SubscriptionType { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime SubscriptionDate { get; set; } = DateTime.Today;

        [Range(1, 60, ErrorMessage = "Length must be between 1 and 60 months.")]
        public int SubscriptionLengthMonths { get; set; }

        [Required(ErrorMessage = "Please select the employee handling this subscription.")]
        public int EmployeeId { get; set; }
    }

    public class PlaneProvider
    {
        public int PlaneId { get; set; }

        [Required(ErrorMessage = "Please select a location.")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a plane type.")]
        public string PlaneType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a ticket class.")]
        public string Tickets { get; set; } = string.Empty;

        [StringLength(200)]
        public string Services { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select the managing employee.")]
        public int EmployeeId { get; set; }
    }

    public class TransportProvider
    {
        public int TransportId { get; set; }

        [Required(ErrorMessage = "Please select a location.")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a transport type.")]
        public string TransportType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select an insurance option.")]
        public string Insurance { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select the managing employee.")]
        public int EmployeeId { get; set; }
    }

    public class HotelProvider
    {
        public int HotelId { get; set; }

        [Required(ErrorMessage = "Please select a hotel type.")]
        public string HotelType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a location.")]
        public string Location { get; set; } = string.Empty;

        [Range(1, 5, ErrorMessage = "Rating must be between 1 and 5.")]
        public int Rating { get; set; }

        // Stored as a comma-separated list built from checkbox selections
        public string Services { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select the managing employee.")]
        public int EmployeeId { get; set; }
    }

    public class EntertainmentProvider
    {
        public int EntertainmentId { get; set; }

        [Required(ErrorMessage = "Please select an entertainment type.")]
        public string EntertainmentType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a food option.")]
        public string Food { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a location.")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select the managing employee.")]
        public int EmployeeId { get; set; }
    }

    // ---------- Authentication ----------
    public class AppUser
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty; // plain text for demo only - hash in production
        public string Role { get; set; } = string.Empty;      // "Admin" or "Employee"
        public string Email { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
    }
}
