using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.HotelProviders
{
    public class IndexModel : PageModel
    {
        public List<HotelProvider> Results { get; set; } = new();
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] HotelTypes => Lookups.HotelTypes;
        public string[] HotelServices => Lookups.HotelServices;
        public string? CurrentSearch { get; set; }
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public HotelProvider NewHotelProvider { get; set; } = new();

        // Bound separately from the model because Services is stored as a
        // single comma-separated string but entered via multiple checkboxes.
        [BindProperty]
        public List<string> SelectedServices { get; set; } = new();

        public void OnGet(string? search)
        {
            CurrentSearch = search;
            IEnumerable<HotelProvider> query = DataStore.HotelProviders;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(h =>
                    h.Location.ToLowerInvariant().Contains(term) ||
                    h.HotelType.ToLowerInvariant().Contains(term) ||
                    h.Services.ToLowerInvariant().Contains(term));
            }

            Results = query.OrderByDescending(h => h.Rating).ToList();
        }

        public IActionResult OnPostAdd()
        {
            NewHotelProvider.Services = string.Join(", ", SelectedServices);

            if (SelectedServices.Count == 0)
            {
                ModelState.AddModelError(string.Empty, "Select at least one service.");
            }

            if (!ModelState.IsValid)
            {
                OnGet(null);
                return Page();
            }

            NewHotelProvider.HotelId = DataStore.NextId(DataStore.HotelProviders, h => h.HotelId);
            DataStore.HotelProviders.Add(NewHotelProvider);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var item = DataStore.HotelProviders.FirstOrDefault(h => h.HotelId == id);
            if (item != null)
            {
                DataStore.HotelProviders.Remove(item);
            }
            return RedirectToPage();
        }
    }
}
