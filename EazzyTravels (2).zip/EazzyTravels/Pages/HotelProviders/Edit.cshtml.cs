using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.HotelProviders
{
    public class EditModel : PageModel
    {
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] HotelTypes => Lookups.HotelTypes;
        public string[] HotelServices => Lookups.HotelServices;

        [BindProperty]
        public HotelProvider HotelProvider { get; set; } = new();

        [BindProperty]
        public List<string> SelectedServices { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.HotelProviders.FirstOrDefault(h => h.HotelId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            HotelProvider = existing;
            SelectedServices = existing.Services
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .ToList();
            return Page();
        }

        public IActionResult OnPost()
        {
            HotelProvider.Services = string.Join(", ", SelectedServices);

            if (SelectedServices.Count == 0)
            {
                ModelState.AddModelError(string.Empty, "Select at least one service.");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.HotelProviders.FirstOrDefault(h => h.HotelId == HotelProvider.HotelId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.HotelType = HotelProvider.HotelType;
            existing.Location = HotelProvider.Location;
            existing.Rating = HotelProvider.Rating;
            existing.Services = HotelProvider.Services;
            existing.EmployeeId = HotelProvider.EmployeeId;

            return RedirectToPage("Index");
        }
    }
}
