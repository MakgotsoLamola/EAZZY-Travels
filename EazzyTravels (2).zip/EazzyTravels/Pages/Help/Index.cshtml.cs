using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EazzyTravels.Pages.Help
{
    public class IndexModel : PageModel
    {
        public class HelpTopic
        {
            public string Title { get; set; } = string.Empty;
            public string Body { get; set; } = string.Empty;
        }

        public static readonly List<HelpTopic> AllTopics = new()
        {
            new HelpTopic { Title = "Logging in", Body = "Enter your username and password, then check your email for a 6-digit one-time code. Enter the code within 5 minutes to finish signing in. If no email server is configured, the code is shown on screen for demo purposes." },
            new HelpTopic { Title = "Admin vs Employee accounts", Body = "Both roles can add and edit records. Only Admin accounts can delete records, to protect the data from accidental removal by front-desk staff." },
            new HelpTopic { Title = "Adding an employee", Body = "Go to Employees, fill in the Add New Employee form at the bottom of the page, and click Save Employee. Contact Info must be a valid email address or a 10-digit South African phone number." },
            new HelpTopic { Title = "Adding a customer", Body = "Go to Customers and use the Add New Customer form. Customers must be 18 or older." },
            new HelpTopic { Title = "Subscriptions - one per customer", Body = "Each customer may only have one active subscription at a time. If you try to add a second subscription for the same customer, the system will show a validation error - edit their existing subscription instead." },
            new HelpTopic { Title = "Searching a table", Body = "Every records page has a search box above the table. Type any keyword (name, location, type, etc.) and click Search. Click Clear to see all records again." },
            new HelpTopic { Title = "Sorting a table", Body = "On pages like Employees, Customers, Subscriptions and Reports, click any underlined column heading to sort by that column. Click it again to reverse the order." },
            new HelpTopic { Title = "Editing a record", Body = "Click the Edit link next to any row to open its edit form, make changes, and click Save Changes." },
            new HelpTopic { Title = "Deleting a record", Body = "Only Admin accounts see the Delete button. Deleting is permanent, so a confirmation pop-up always appears first." },
            new HelpTopic { Title = "Reports", Body = "The Reports page shows totals for every table plus a calculated subscription revenue report you can search and sort." },
            new HelpTopic { Title = "Tooltips", Body = "Hover your mouse over any field label or the small (?) icon next to a label to see a short explanation of what that field is for." },
        };

        public List<HelpTopic> Results { get; set; } = AllTopics;
        public string? CurrentSearch { get; set; }

        public void OnGet(string? search)
        {
            CurrentSearch = search;
            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                Results = AllTopics.Where(t =>
                    t.Title.ToLowerInvariant().Contains(term) ||
                    t.Body.ToLowerInvariant().Contains(term)).ToList();
            }
        }
    }
}
