using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;

namespace EazzyTravels.Pages
{
    public class IndexModel : PageModel
    {
        public int EmployeeCount => DataStore.Employees.Count;
        public int CustomerCount => DataStore.Customers.Count;
        public int SubscriptionCount => DataStore.Subscriptions.Count;
        public int ProviderCount =>
            DataStore.PlaneProviders.Count +
            DataStore.TransportProviders.Count +
            DataStore.HotelProviders.Count +
            DataStore.EntertainmentProviders.Count;

        public void OnGet() { }
    }
}
