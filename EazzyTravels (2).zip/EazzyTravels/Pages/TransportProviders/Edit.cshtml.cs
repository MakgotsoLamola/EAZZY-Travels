using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.TransportProviders
{
    public class EditModel : PageModel
    {
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] TransportTypes => Lookups.TransportTypes;
        public string[] InsuranceOptions => Lookups.InsuranceOptions;

        [BindProperty]
        public TransportProvider TransportProvider { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.TransportProviders.FirstOrDefault(t => t.TransportId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            TransportProvider = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.TransportProviders.FirstOrDefault(t => t.TransportId == TransportProvider.TransportId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.Location = TransportProvider.Location;
            existing.TransportType = TransportProvider.TransportType;
            existing.Insurance = TransportProvider.Insurance;
            existing.EmployeeId = TransportProvider.EmployeeId;

            return RedirectToPage("Index");
        }
    }
}
