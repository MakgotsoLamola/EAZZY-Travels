using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.TransportProviders
{
    public class IndexModel : PageModel
    {
        public List<TransportProvider> Results { get; set; } = new();
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] TransportTypes => Lookups.TransportTypes;
        public string[] InsuranceOptions => Lookups.InsuranceOptions;
        public string? CurrentSearch { get; set; }
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public TransportProvider NewTransportProvider { get; set; } = new();

        public void OnGet(string? search)
        {
            CurrentSearch = search;
            IEnumerable<TransportProvider> query = DataStore.TransportProviders;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(t =>
                    t.Location.ToLowerInvariant().Contains(term) ||
                    t.TransportType.ToLowerInvariant().Contains(term) ||
                    t.Insurance.ToLowerInvariant().Contains(term));
            }

            Results = query.OrderBy(t => t.Location).ToList();
        }

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                OnGet(null);
                return Page();
            }

            NewTransportProvider.TransportId = DataStore.NextId(DataStore.TransportProviders, t => t.TransportId);
            DataStore.TransportProviders.Add(NewTransportProvider);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var item = DataStore.TransportProviders.FirstOrDefault(t => t.TransportId == id);
            if (item != null)
            {
                DataStore.TransportProviders.Remove(item);
            }
            return RedirectToPage();
        }
    }
}
