using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.EntertainmentProviders
{
    public class EditModel : PageModel
    {
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] EntertainmentTypes => Lookups.EntertainmentTypes;
        public string[] FoodOptions => Lookups.FoodOptions;

        [BindProperty]
        public EntertainmentProvider EntertainmentProvider { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.EntertainmentProviders.FirstOrDefault(x => x.EntertainmentId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            EntertainmentProvider = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.EntertainmentProviders.FirstOrDefault(x => x.EntertainmentId == EntertainmentProvider.EntertainmentId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.EntertainmentType = EntertainmentProvider.EntertainmentType;
            existing.Food = EntertainmentProvider.Food;
            existing.Location = EntertainmentProvider.Location;
            existing.EmployeeId = EntertainmentProvider.EmployeeId;

            return RedirectToPage("Index");
        }
    }
}
