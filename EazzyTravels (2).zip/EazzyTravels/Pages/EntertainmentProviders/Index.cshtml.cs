using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.EntertainmentProviders
{
    public class IndexModel : PageModel
    {
        public List<EntertainmentProvider> Results { get; set; } = new();
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] EntertainmentTypes => Lookups.EntertainmentTypes;
        public string[] FoodOptions => Lookups.FoodOptions;
        public string? CurrentSearch { get; set; }
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public EntertainmentProvider NewEntertainmentProvider { get; set; } = new();

        public void OnGet(string? search)
        {
            CurrentSearch = search;
            IEnumerable<EntertainmentProvider> query = DataStore.EntertainmentProviders;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(x =>
                    x.EntertainmentType.ToLowerInvariant().Contains(term) ||
                    x.Food.ToLowerInvariant().Contains(term) ||
                    x.Location.ToLowerInvariant().Contains(term));
            }

            Results = query.OrderBy(x => x.Location).ToList();
        }

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                OnGet(null);
                return Page();
            }

            NewEntertainmentProvider.EntertainmentId = DataStore.NextId(DataStore.EntertainmentProviders, x => x.EntertainmentId);
            DataStore.EntertainmentProviders.Add(NewEntertainmentProvider);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var item = DataStore.EntertainmentProviders.FirstOrDefault(x => x.EntertainmentId == id);
            if (item != null)
            {
                DataStore.EntertainmentProviders.Remove(item);
            }
            return RedirectToPage();
        }
    }
}
