using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Subscriptions
{
    public class IndexModel : PageModel
    {
        public List<Subscription> Results { get; set; } = new();
        public List<Customer> Customers => DataStore.Customers;
        public List<Employee> Employees => DataStore.Employees;
        public string[] SubscriptionTypes => Lookups.SubscriptionTypes;
        public string? CurrentSearch { get; set; }
        public string CurrentSort { get; set; } = "Date";
        public string CurrentDir { get; set; } = "desc";
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public Subscription NewSubscription { get; set; } = new();

        public void OnGet(string? search, string? sortBy, string? sortDir)
        {
            CurrentSearch = search;
            CurrentSort = string.IsNullOrEmpty(sortBy) ? "Date" : sortBy;
            CurrentDir = sortDir == "asc" ? "asc" : "desc";

            IEnumerable<Subscription> query = DataStore.Subscriptions;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(s =>
                    CustomerName(s.CustomerId).ToLowerInvariant().Contains(term) ||
                    s.SubscriptionType.ToLowerInvariant().Contains(term));
            }

            query = CurrentSort switch
            {
                "Type" => CurrentDir == "asc" ? query.OrderBy(s => s.SubscriptionType) : query.OrderByDescending(s => s.SubscriptionType),
                "Length" => CurrentDir == "asc" ? query.OrderBy(s => s.SubscriptionLengthMonths) : query.OrderByDescending(s => s.SubscriptionLengthMonths),
                _ => CurrentDir == "asc" ? query.OrderBy(s => s.SubscriptionDate) : query.OrderByDescending(s => s.SubscriptionDate),
            };

            Results = query.ToList();
        }

        public IActionResult OnPostAdd()
        {
            // Business rule: one subscription per customer.
            if (DataStore.Subscriptions.Any(s => s.CustomerId == NewSubscription.CustomerId))
            {
                ModelState.AddModelError(string.Empty, "This customer already has an active subscription. Edit their existing subscription instead of adding a new one.");
            }

            if (!ModelState.IsValid)
            {
                OnGet(null, null, null);
                return Page();
            }

            NewSubscription.SubscriptionId = DataStore.NextId(DataStore.Subscriptions, s => s.SubscriptionId);
            DataStore.Subscriptions.Add(NewSubscription);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var sub = DataStore.Subscriptions.FirstOrDefault(s => s.SubscriptionId == id);
            if (sub != null)
            {
                DataStore.Subscriptions.Remove(sub);
            }
            return RedirectToPage();
        }

        public string CustomerName(int customerId)
        {
            var c = Customers.FirstOrDefault(x => x.CustomerId == customerId);
            return c == null ? "Unknown" : $"{c.FirstName} {c.LastName}";
        }
    }
}
