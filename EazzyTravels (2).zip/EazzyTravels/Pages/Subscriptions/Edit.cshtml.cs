using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Subscriptions
{
    public class EditModel : PageModel
    {
        public List<Customer> Customers => DataStore.Customers;
        public List<Employee> Employees => DataStore.Employees;
        public string[] SubscriptionTypes => Lookups.SubscriptionTypes;

        [BindProperty]
        public Subscription Subscription { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.Subscriptions.FirstOrDefault(s => s.SubscriptionId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            Subscription = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            // Still enforce one-subscription-per-customer, excluding this record itself.
            if (DataStore.Subscriptions.Any(s => s.CustomerId == Subscription.CustomerId && s.SubscriptionId != Subscription.SubscriptionId))
            {
                ModelState.AddModelError(string.Empty, "This customer already has a different active subscription.");
            }

            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.Subscriptions.FirstOrDefault(s => s.SubscriptionId == Subscription.SubscriptionId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.CustomerId = Subscription.CustomerId;
            existing.SubscriptionType = Subscription.SubscriptionType;
            existing.SubscriptionDate = Subscription.SubscriptionDate;
            existing.SubscriptionLengthMonths = Subscription.SubscriptionLengthMonths;
            existing.EmployeeId = Subscription.EmployeeId;

            return RedirectToPage("Index");
        }
    }
}
