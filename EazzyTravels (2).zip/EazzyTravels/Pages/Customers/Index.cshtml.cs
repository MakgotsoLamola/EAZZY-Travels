using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Customers
{
    public class IndexModel : PageModel
    {
        public List<Customer> Results { get; set; } = new();
        public string? CurrentSearch { get; set; }
        public string CurrentSort { get; set; } = "Name";
        public string CurrentDir { get; set; } = "asc";
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public Customer NewCustomer { get; set; } = new();

        public void OnGet(string? search, string? sortBy, string? sortDir)
        {
            CurrentSearch = search;
            CurrentSort = string.IsNullOrEmpty(sortBy) ? "Name" : sortBy;
            CurrentDir = sortDir == "desc" ? "desc" : "asc";

            IEnumerable<Customer> query = DataStore.Customers;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(c =>
                    c.FirstName.ToLowerInvariant().Contains(term) ||
                    c.LastName.ToLowerInvariant().Contains(term) ||
                    c.ContactInfo.ToLowerInvariant().Contains(term));
            }

            query = CurrentSort switch
            {
                "Age" => CurrentDir == "asc" ? query.OrderBy(c => c.Age) : query.OrderByDescending(c => c.Age),
                "MaritalStatus" => CurrentDir == "asc" ? query.OrderBy(c => c.MaritalStatus) : query.OrderByDescending(c => c.MaritalStatus),
                _ => CurrentDir == "asc" ? query.OrderBy(c => c.FirstName).ThenBy(c => c.LastName)
                                          : query.OrderByDescending(c => c.FirstName).ThenByDescending(c => c.LastName),
            };

            Results = query.ToList();
        }

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                OnGet(null, null, null);
                return Page();
            }

            NewCustomer.CustomerId = DataStore.NextId(DataStore.Customers, c => c.CustomerId);
            DataStore.Customers.Add(NewCustomer);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var customer = DataStore.Customers.FirstOrDefault(c => c.CustomerId == id);
            if (customer != null)
            {
                DataStore.Customers.Remove(customer);
                // Keep subscriptions consistent: remove any subscription tied to this customer too.
                DataStore.Subscriptions.RemoveAll(s => s.CustomerId == id);
            }
            return RedirectToPage();
        }
    }
}
