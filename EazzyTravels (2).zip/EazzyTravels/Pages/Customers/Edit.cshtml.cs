using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Customers
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public Customer Customer { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.Customers.FirstOrDefault(c => c.CustomerId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            Customer = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.Customers.FirstOrDefault(c => c.CustomerId == Customer.CustomerId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.FirstName = Customer.FirstName;
            existing.LastName = Customer.LastName;
            existing.Age = Customer.Age;
            existing.ContactInfo = Customer.ContactInfo;
            existing.MaritalStatus = Customer.MaritalStatus;

            return RedirectToPage("Index");
        }
    }
}
