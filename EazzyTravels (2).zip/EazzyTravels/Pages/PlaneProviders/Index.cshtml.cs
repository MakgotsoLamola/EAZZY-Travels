using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.PlaneProviders
{
    public class IndexModel : PageModel
    {
        public List<PlaneProvider> Results { get; set; } = new();
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] PlaneTypes => Lookups.PlaneTypes;
        public string[] TicketClasses => Lookups.TicketClasses;
        public string? CurrentSearch { get; set; }
        public bool IsAdmin => User.IsInRole("Admin");

        [BindProperty]
        public PlaneProvider NewPlaneProvider { get; set; } = new();

        public void OnGet(string? search)
        {
            CurrentSearch = search;
            IEnumerable<PlaneProvider> query = DataStore.PlaneProviders;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(p =>
                    p.Location.ToLowerInvariant().Contains(term) ||
                    p.PlaneType.ToLowerInvariant().Contains(term) ||
                    p.Tickets.ToLowerInvariant().Contains(term));
            }

            Results = query.OrderBy(p => p.Location).ToList();
        }

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                OnGet(null);
                return Page();
            }

            NewPlaneProvider.PlaneId = DataStore.NextId(DataStore.PlaneProviders, p => p.PlaneId);
            DataStore.PlaneProviders.Add(NewPlaneProvider);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var item = DataStore.PlaneProviders.FirstOrDefault(p => p.PlaneId == id);
            if (item != null)
            {
                DataStore.PlaneProviders.Remove(item);
            }
            return RedirectToPage();
        }
    }
}
