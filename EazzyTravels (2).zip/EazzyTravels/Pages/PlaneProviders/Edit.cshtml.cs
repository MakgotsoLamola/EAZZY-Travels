using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.PlaneProviders
{
    public class EditModel : PageModel
    {
        public List<Employee> Employees => DataStore.Employees;
        public string[] Locations => Lookups.Locations;
        public string[] PlaneTypes => Lookups.PlaneTypes;
        public string[] TicketClasses => Lookups.TicketClasses;

        [BindProperty]
        public PlaneProvider PlaneProvider { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.PlaneProviders.FirstOrDefault(p => p.PlaneId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            PlaneProvider = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.PlaneProviders.FirstOrDefault(p => p.PlaneId == PlaneProvider.PlaneId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.Location = PlaneProvider.Location;
            existing.PlaneType = PlaneProvider.PlaneType;
            existing.Tickets = PlaneProvider.Tickets;
            existing.Services = PlaneProvider.Services;
            existing.EmployeeId = PlaneProvider.EmployeeId;

            return RedirectToPage("Index");
        }
    }
}
