using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Reports
{
    // A lightweight "reports" view: totals per entity, plus a searchable /
    // sortable calculated report (subscription revenue estimate) so markers
    // can see calculations, sorting and searching all in one place.
    public class IndexModel : PageModel
    {
        public int EmployeeCount => DataStore.Employees.Count;
        public int CustomerCount => DataStore.Customers.Count;
        public int SubscriptionCount => DataStore.Subscriptions.Count;
        public int PlaneCount => DataStore.PlaneProviders.Count;
        public int TransportCount => DataStore.TransportProviders.Count;
        public int HotelCount => DataStore.HotelProviders.Count;
        public int EntertainmentCount => DataStore.EntertainmentProviders.Count;

        public class SubscriptionReportRow
        {
            public int SubscriptionId { get; set; }
            public string CustomerName { get; set; } = string.Empty;
            public string SubscriptionType { get; set; } = string.Empty;
            public int LengthMonths { get; set; }
            public decimal MonthlyRate { get; set; }
            public decimal EstimatedTotal { get; set; }
            public string HandledBy { get; set; } = string.Empty;
        }

        public List<SubscriptionReportRow> Rows { get; set; } = new();
        public decimal GrandTotal => Rows.Sum(r => r.EstimatedTotal);
        public string? CurrentSearch { get; set; }
        public string CurrentSort { get; set; } = "Total";
        public string CurrentDir { get; set; } = "desc";

        // Simple illustrative monthly rate per subscription tier, used to
        // demonstrate a calculated report (rate x length = estimated total).
        private static decimal MonthlyRateFor(string type) => type switch
        {
            "Premium" => 1499m,
            "Standard" => 899m,
            _ => 449m, // Basic
        };

        public void OnGet(string? search, string? sortBy, string? sortDir)
        {
            CurrentSearch = search;
            CurrentSort = string.IsNullOrEmpty(sortBy) ? "Total" : sortBy;
            CurrentDir = sortDir == "asc" ? "asc" : "desc";

            var rows = DataStore.Subscriptions.Select(s =>
            {
                var customer = DataStore.Customers.FirstOrDefault(c => c.CustomerId == s.CustomerId);
                var employee = DataStore.Employees.FirstOrDefault(e => e.EmployeeId == s.EmployeeId);
                var rate = MonthlyRateFor(s.SubscriptionType);
                return new SubscriptionReportRow
                {
                    SubscriptionId = s.SubscriptionId,
                    CustomerName = customer == null ? "Unknown" : $"{customer.FirstName} {customer.LastName}",
                    SubscriptionType = s.SubscriptionType,
                    LengthMonths = s.SubscriptionLengthMonths,
                    MonthlyRate = rate,
                    EstimatedTotal = rate * s.SubscriptionLengthMonths,
                    HandledBy = employee == null ? "Unknown" : $"{employee.FirstName} {employee.LastName}",
                };
            });

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                rows = rows.Where(r =>
                    r.CustomerName.ToLowerInvariant().Contains(term) ||
                    r.SubscriptionType.ToLowerInvariant().Contains(term) ||
                    r.HandledBy.ToLowerInvariant().Contains(term));
            }

            rows = CurrentSort switch
            {
                "Customer" => CurrentDir == "asc" ? rows.OrderBy(r => r.CustomerName) : rows.OrderByDescending(r => r.CustomerName),
                "Type" => CurrentDir == "asc" ? rows.OrderBy(r => r.SubscriptionType) : rows.OrderByDescending(r => r.SubscriptionType),
                "Length" => CurrentDir == "asc" ? rows.OrderBy(r => r.LengthMonths) : rows.OrderByDescending(r => r.LengthMonths),
                _ => CurrentDir == "asc" ? rows.OrderBy(r => r.EstimatedTotal) : rows.OrderByDescending(r => r.EstimatedTotal),
            };

            Rows = rows.ToList();
        }
    }
}
