using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Employees
{
    public class EditModel : PageModel
    {
        [BindProperty]
        public Employee Employee { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var existing = DataStore.Employees.FirstOrDefault(e => e.EmployeeId == id);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }
            Employee = existing;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existing = DataStore.Employees.FirstOrDefault(e => e.EmployeeId == Employee.EmployeeId);
            if (existing == null)
            {
                return RedirectToPage("Index");
            }

            existing.FirstName = Employee.FirstName;
            existing.LastName = Employee.LastName;
            existing.Role = Employee.Role;
            existing.ContactInfo = Employee.ContactInfo;
            existing.Salary = Employee.Salary;
            existing.DateOfHire = Employee.DateOfHire;
            existing.EmploymentStatus = Employee.EmploymentStatus;

            return RedirectToPage("Index");
        }
    }
}
