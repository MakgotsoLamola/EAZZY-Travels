using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Models;

namespace EazzyTravels.Pages.Employees
{
    public class IndexModel : PageModel
    {
        public List<Employee> Results { get; set; } = new();
        public string? CurrentSearch { get; set; }
        public string CurrentSort { get; set; } = "Name";
        public string CurrentDir { get; set; } = "asc";
        public bool IsAdmin => User.IsInRole("Admin");

        public void OnGet(string? search, string? sortBy, string? sortDir)
        {
            CurrentSearch = search;
            CurrentSort = string.IsNullOrEmpty(sortBy) ? "Name" : sortBy;
            CurrentDir = sortDir == "desc" ? "desc" : "asc";

            IEnumerable<Employee> query = DataStore.Employees;

            if (!string.IsNullOrWhiteSpace(search))
            {
                var term = search.Trim().ToLowerInvariant();
                query = query.Where(e =>
                    e.FirstName.ToLowerInvariant().Contains(term) ||
                    e.LastName.ToLowerInvariant().Contains(term) ||
                    e.Role.ToLowerInvariant().Contains(term) ||
                    e.ContactInfo.ToLowerInvariant().Contains(term));
            }

            query = CurrentSort switch
            {
                "Role" => CurrentDir == "asc" ? query.OrderBy(e => e.Role) : query.OrderByDescending(e => e.Role),
                "Salary" => CurrentDir == "asc" ? query.OrderBy(e => e.Salary) : query.OrderByDescending(e => e.Salary),
                "DateOfHire" => CurrentDir == "asc" ? query.OrderBy(e => e.DateOfHire) : query.OrderByDescending(e => e.DateOfHire),
                _ => CurrentDir == "asc" ? query.OrderBy(e => e.FirstName).ThenBy(e => e.LastName)
                                          : query.OrderByDescending(e => e.FirstName).ThenByDescending(e => e.LastName),
            };

            Results = query.ToList();
        }

        [BindProperty]
        public Employee NewEmployee { get; set; } = new();

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                OnGet(null, null, null);
                return Page();
            }

            NewEmployee.EmployeeId = DataStore.NextId(DataStore.Employees, e => e.EmployeeId);
            DataStore.Employees.Add(NewEmployee);
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            if (!IsAdmin)
            {
                return Forbid();
            }

            var employee = DataStore.Employees.FirstOrDefault(e => e.EmployeeId == id);
            if (employee != null)
            {
                DataStore.Employees.Remove(employee);
            }
            return RedirectToPage();
        }
    }
}
