using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Services;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace EazzyTravels.Pages.Account
{
    public class VerifyOtpModel : PageModel
    {
        private readonly OtpService _otpService;

        public VerifyOtpModel(OtpService otpService)
        {
            _otpService = otpService;
        }

        [BindProperty]
        [Required(ErrorMessage = "Enter the 6-digit code we emailed you.")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "The code must be exactly 6 digits.")]
        public string Code { get; set; } = string.Empty;

        public string? ErrorMessage { get; set; }
        public string? DemoOtpNotice { get; set; }
        public string Username { get; private set; } = string.Empty;

        public IActionResult OnGet()
        {
            var pendingUsername = TempData.Peek("PendingUsername") as string;
            if (string.IsNullOrEmpty(pendingUsername))
            {
                return RedirectToPage("Login");
            }
            Username = pendingUsername;
            DemoOtpNotice = TempData.Peek("DemoOtpNotice") as string;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var pendingUsername = TempData.Peek("PendingUsername") as string;
            if (string.IsNullOrEmpty(pendingUsername))
            {
                return RedirectToPage("Login");
            }
            Username = pendingUsername;

            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (!_otpService.ValidateOtp(pendingUsername, Code))
            {
                ErrorMessage = "That code is incorrect or has expired.";
                return Page();
            }

            var user = UserStore.Users.First(u =>
                string.Equals(u.Username, pendingUsername, StringComparison.OrdinalIgnoreCase));

            var claims = new List<Claim>
            {
                new(ClaimTypes.Name, user.DisplayName),
                new(ClaimTypes.Role, user.Role),
                new("Username", user.Username)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(identity));

            TempData.Remove("PendingUsername");
            return RedirectToPage("/Index");
        }
    }
}
