using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using EazzyTravels.Data;
using EazzyTravels.Services;
using System.ComponentModel.DataAnnotations;

namespace EazzyTravels.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly OtpService _otpService;
        private readonly IEmailSender _emailSender;

        public LoginModel(OtpService otpService, IEmailSender emailSender)
        {
            _otpService = otpService;
            _emailSender = emailSender;
        }

        [BindProperty]
        [Required(ErrorMessage = "Username is required.")]
        public string Username { get; set; } = string.Empty;

        [BindProperty]
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        public string? ErrorMessage { get; set; }
        public string? DemoOtpNotice { get; set; }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var user = UserStore.Validate(Username, Password);
            if (user == null)
            {
                ErrorMessage = "Invalid username or password.";
                return Page();
            }

            // Step 2 of login: generate + email a one-time-password
            var otp = _otpService.GenerateOtp(user.Username);
            await _emailSender.SendAsync(
                user.Email,
                "Your EaZZy-Travels login code",
                $"Hi {user.DisplayName}, your one-time login code is {otp}. It expires in 5 minutes.");

            TempData["PendingUsername"] = user.Username;

            // If no real SMTP server is configured, SmtpEmailSender keeps the code so we can
            // show it on screen for demo/marking purposes instead of silently failing.
            if (SmtpEmailSender.LastMessageSentForDemo != null)
            {
                TempData["DemoOtpNotice"] = $"No SMTP server configured - here is the code that would have been emailed: {otp}";
            }

            return RedirectToPage("VerifyOtp");
        }
    }
}
