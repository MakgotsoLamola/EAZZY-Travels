using System.Collections.Concurrent;

namespace EazzyTravels.Services
{
    // Generates and validates one-time-passwords for the login flow.
    // In-memory store keyed by username - fine for a single-server demo;
    // use a cache (Redis) or DB table if you scale this out.
    public class OtpService
    {
        private class OtpEntry
        {
            public string Code { get; set; } = string.Empty;
            public DateTime ExpiresAt { get; set; }
        }

        private static readonly ConcurrentDictionary<string, OtpEntry> _codes = new();
        private static readonly Random _rng = new();

        public string GenerateOtp(string username)
        {
            var code = _rng.Next(100000, 999999).ToString();
            _codes[username.ToLowerInvariant()] = new OtpEntry
            {
                Code = code,
                ExpiresAt = DateTime.UtcNow.AddMinutes(5)
            };
            return code;
        }

        public bool ValidateOtp(string username, string enteredCode)
        {
            if (!_codes.TryGetValue(username.ToLowerInvariant(), out var entry))
            {
                return false;
            }

            if (DateTime.UtcNow > entry.ExpiresAt)
            {
                _codes.TryRemove(username.ToLowerInvariant(), out _);
                return false;
            }

            var isValid = entry.Code == enteredCode.Trim();
            if (isValid)
            {
                _codes.TryRemove(username.ToLowerInvariant(), out _);
            }
            return isValid;
        }
    }
}
