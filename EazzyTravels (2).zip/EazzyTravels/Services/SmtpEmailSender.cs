using System.Net;
using System.Net.Mail;

namespace EazzyTravels.Services
{
    // Sends real email via SMTP when appsettings.json / user-secrets have Smtp:Host etc. set.
    // If no SMTP host is configured (the default, out of the box) it falls back to writing
    // the message to the console/log instead of failing, and remembers the last message so
    // the Login page can show it on screen - handy for local demos and markers who don't
    // want to set up a real mailbox.
    public class SmtpEmailSender : IEmailSender
    {
        private readonly IConfiguration _config;
        public static string? LastMessageSentForDemo { get; private set; }

        public SmtpEmailSender(IConfiguration config)
        {
            _config = config;
        }

        public async Task SendAsync(string toEmail, string subject, string body)
        {
            var host = _config["Smtp:Host"];

            if (string.IsNullOrWhiteSpace(host))
            {
                // No SMTP configured - fall back to console + on-screen demo message.
                Console.WriteLine($"[DEMO EMAIL] To: {toEmail} | Subject: {subject} | Body: {body}");
                LastMessageSentForDemo = $"{subject}: {body}";
                return;
            }

            var port = int.TryParse(_config["Smtp:Port"], out var p) ? p : 587;
            var user = _config["Smtp:User"] ?? "";
            var pass = _config["Smtp:Password"] ?? "";
            var from = _config["Smtp:From"] ?? user;

            using var client = new SmtpClient(host, port)
            {
                Credentials = new NetworkCredential(user, pass),
                EnableSsl = true
            };

            using var message = new MailMessage(from, toEmail, subject, body);
            await client.SendMailAsync(message);
        }
    }
}
