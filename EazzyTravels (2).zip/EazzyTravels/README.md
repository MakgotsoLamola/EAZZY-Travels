# EaZZy-Travels Record-Keeping System

An ASP.NET Core Razor Pages website (C# + HTML/Razor) for the EaZZy-Travels
travel agency, covering every entity from the Phase 3 data model: Employees,
Customers, Subscriptions, Plane Providers, Transport Providers, Hotel
Providers and Entertainment Providers.

## How to open in Visual Studio

1. Make sure you have the **.NET 8 SDK** and the **ASP.NET and web
   development** workload installed (Visual Studio Installer -> Modify).
2. Unzip this project to a permanent folder (not inside the zip, not in
   Downloads).
3. Double-click **EazzyTravels.sln**. This opens the whole solution in
   Visual Studio with Solution Explorer populated.
4. Press **F5** (or Ctrl+F5 to run without the debugger attached).
5. Your browser opens to the login page.

## Login (two account types + email OTP)

| Role     | Username   | Password      |
|----------|-----------|---------------|
| Admin    | `admin`    | `Admin@123`    |
| Employee | `employee` | `Employee@123` |

After the password, a 6-digit one-time code is generated and "emailed" to
the account's address. **No real mail server is configured out of the box**,
so the code is shown on screen instead (clearly labelled "DEMO EMAIL") -
enter it to finish logging in.

To send real emails, fill in the `Smtp` section of `appsettings.json`
(Host, Port, User, Password, From) with a real provider's SMTP details
(Gmail, Outlook365, SendGrid, etc.). Once `Smtp:Host` is non-empty, the
system automatically sends real emails instead of the on-screen demo code.

**Role permissions:** both roles can add and edit every table; only the
**Admin** account can delete records (the Delete button is hidden entirely
for Employee accounts, and also blocked server-side if attempted directly).

## What's included

- Full **CRUD** (Create, Read, Update, Delete) for all 7 tables in the data
  model, with server-side validation on every field (required fields, email/
  phone format, numeric ranges, string lengths).
- **Business rule**: each customer may hold only one subscription at a time -
  enforced on both Add and Edit.
- **Dropdowns / radio groups / checkboxes** in place of free text where it
  makes the form easier to use correctly:
  - Plane Providers: Location & Plane Type (dropdowns), Ticket Class (radio)
  - Transport Providers: Location, Transport Type & Insurance (dropdowns)
  - Hotel Providers: Location & Hotel Type (dropdowns), Services (checkboxes)
  - Entertainment Providers: Location & Type (dropdowns), Food (radio)
- **Search** box on every records page (Employees, Customers, Subscriptions,
  all 4 providers, and Reports) - filters by any relevant field.
- **Sortable columns** on Employees, Customers, Subscriptions and Reports -
  click a column heading to sort, click again to reverse.
- **Reports page** (`/Reports`) with entity totals and a calculated,
  searchable, sortable subscription-revenue report.
- **Help page** (`/Help`) with a keyword search box over FAQ topics, plus
  hover tooltips (the small **?** icons and native browser tooltips) on
  form fields throughout the site explaining what each field is for.
- **Real, non-AI stock photography** (via Lorem Picsum, which serves real
  Unsplash photographs, free to use) on the homepage and every provider
  page, styled after listing sites like Booking.com.
- Purple / white / black theme matching the original proposal document.

## Project structure

- `Program.cs` - startup, authentication & authorization configuration
- `Models/Models.cs` - C# classes for every entity + the `Lookups` class
  holding all dropdown/radio/checkbox option lists
- `Data/DataStore.cs` - in-memory storage (swap for MySQL/EF Core later)
- `Data/UserStore.cs` - the two demo login accounts
- `Services/` - OTP generation (`OtpService`) and email sending
  (`IEmailSender` / `SmtpEmailSender`)
- `Pages/Account/` - Login, VerifyOtp (OTP entry) and Logout
- `Pages/Reports/`, `Pages/Help/` - reporting and help/FAQ pages
- `Pages/<Entity>/Index.cshtml(.cs)` - list + search/sort + add form
- `Pages/<Entity>/Edit.cshtml(.cs)` - update form for that entity
- `Pages/Shared/_Layout.cshtml` - main layout with navigation + user badge
- `Pages/Shared/_LoginLayout.cshtml` - simpler centred layout for login/OTP
- `wwwroot/css/site.css` - the purple/white/black theme

## Swapping in MySQL later

The proposal specifies MySQL as the database. To connect this to a real
MySQL database:

1. Install the NuGet package `Pomelo.EntityFrameworkCore.MySql`.
2. Create a `EazzyTravelsDbContext : DbContext` with `DbSet<T>` properties
   for each model in `Models/Models.cs` (including `AppUser` if you want
   real accounts with hashed passwords instead of the two demo logins).
3. Register it in `Program.cs` with `builder.Services.AddDbContext<...>()`.
4. Replace `DataStore.Employees` etc. calls in each `Index.cshtml.cs` /
   `Edit.cshtml.cs` with calls to the DbContext.

The page structure, navigation and HTML forms stay exactly the same.

## Using GitHub (bonus marks)

1. Create a new empty repository on GitHub (no README/gitignore, since this
   project already has both).
2. From the `EazzyTravels` folder:
   ```
   git init
   git add .
   git commit -m "Initial commit: EaZZy-Travels record-keeping system"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
3. Commit again after each meaningful change (e.g. "Add hotel checkboxes",
   "Add OTP login flow") to show a clear history of incremental work.
