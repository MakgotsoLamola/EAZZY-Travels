using EazzyTravels.Models;

namespace EazzyTravels.Data
{
    // Simple in-memory data store so the site runs immediately with no database setup.
    // The proposal specifies MySQL for production - swap this class for an
    // Entity Framework Core DbContext (Pomelo.EntityFrameworkCore.MySql) when ready;
    // the Page Models will not need to change much since they only talk to DataStore.
    //
    // NOTE: seed values below deliberately match the fixed option lists in
    // Models.Lookups, since those fields are now dropdowns / radio groups / checkboxes.
    public static class DataStore
    {
        public static List<Employee> Employees { get; } = new()
        {
            new Employee { EmployeeId = 1, FirstName = "Muvhuya", LastName = "Kwinda", Role = "Project Manager", ContactInfo = "muvhuya@eazzytravels.co.za", Salary = 25000, DateOfHire = new DateTime(2023,2,1), EmploymentStatus = "Full-time" },
            new Employee { EmployeeId = 2, FirstName = "Stuart", LastName = "Ngwenya", Role = "System Owner", ContactInfo = "stuart@eazzytravels.co.za", Salary = 32000, DateOfHire = new DateTime(2022,6,15), EmploymentStatus = "Full-time" },
            new Employee { EmployeeId = 3, FirstName = "Thato", LastName = "More", Role = "System Designer", ContactInfo = "0821234567", Salary = 21000, DateOfHire = new DateTime(2024,3,10), EmploymentStatus = "Part-time" },
        };

        public static List<Customer> Customers { get; } = new()
        {
            new Customer { CustomerId = 1, FirstName = "Thabo", LastName = "Mokoena", Age = 34, ContactInfo = "thabo@example.com", MaritalStatus = "Married" },
            new Customer { CustomerId = 2, FirstName = "Amy", LastName = "Green", Age = 27, ContactInfo = "amy@example.com", MaritalStatus = "Single" },
            new Customer { CustomerId = 3, FirstName = "Sipho", LastName = "Dlamini", Age = 41, ContactInfo = "0837654321", MaritalStatus = "Divorced" },
        };

        public static List<Subscription> Subscriptions { get; } = new()
        {
            new Subscription { SubscriptionId = 1, CustomerId = 1, SubscriptionType = "Premium", SubscriptionDate = new DateTime(2026,1,10), SubscriptionLengthMonths = 12, EmployeeId = 1 },
            new Subscription { SubscriptionId = 2, CustomerId = 2, SubscriptionType = "Standard", SubscriptionDate = new DateTime(2026,4,2), SubscriptionLengthMonths = 6, EmployeeId = 2 },
        };

        public static List<PlaneProvider> PlaneProviders { get; } = new()
        {
            new PlaneProvider { PlaneId = 1, Location = "Johannesburg", PlaneType = "Boeing 737", Tickets = "Economy", Services = "In-flight meals, extra baggage", EmployeeId = 1 },
            new PlaneProvider { PlaneId = 2, Location = "Cape Town", PlaneType = "Airbus A320", Tickets = "Business", Services = "Lounge access, priority boarding", EmployeeId = 2 },
        };

        public static List<TransportProvider> TransportProviders { get; } = new()
        {
            new TransportProvider { TransportId = 1, Location = "Cape Town", TransportType = "Shuttle Bus", Insurance = "Comprehensive Cover", EmployeeId = 2 },
            new TransportProvider { TransportId = 2, Location = "Durban", TransportType = "Private Car", Insurance = "Third-Party Cover", EmployeeId = 1 },
        };

        public static List<HotelProvider> HotelProviders { get; } = new()
        {
            new HotelProvider { HotelId = 1, HotelType = "Resort", Location = "Durban", Rating = 4, Services = "Pool, Spa, Wi-Fi", EmployeeId = 1 },
            new HotelProvider { HotelId = 2, HotelType = "Boutique Hotel", Location = "Cape Town", Rating = 5, Services = "Wi-Fi, Restaurant, Parking", EmployeeId = 3 },
        };

        public static List<EntertainmentProvider> EntertainmentProviders { get; } = new()
        {
            new EntertainmentProvider { EntertainmentId = 1, EntertainmentType = "Safari Tour", Food = "Buffet", Location = "Nelspruit", EmployeeId = 2 },
            new EntertainmentProvider { EntertainmentId = 2, EntertainmentType = "Wine Tasting", Food = "A-la-carte", Location = "Cape Town", EmployeeId = 3 },
        };

        // Simple helpers to generate the next ID for each list
        public static int NextId<T>(List<T> list, Func<T, int> selector) =>
            list.Count == 0 ? 1 : list.Max(selector) + 1;
    }
}
