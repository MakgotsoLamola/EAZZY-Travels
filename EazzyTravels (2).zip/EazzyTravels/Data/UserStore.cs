using EazzyTravels.Models;

namespace EazzyTravels.Data
{
    // Two hard-coded login accounts as requested: one Employee, one Admin.
    // Swap this for a real Users table (with hashed passwords) when you connect MySQL.
    public static class UserStore
    {
        public static List<AppUser> Users { get; } = new()
        {
            new AppUser
            {
                Username = "admin",
                Password = "Admin@123",
                Role = "Admin",
                Email = "admin@eazzytravels.co.za",
                DisplayName = "System Administrator"
            },
            new AppUser
            {
                Username = "employee",
                Password = "Employee@123",
                Role = "Employee",
                Email = "employee@eazzytravels.co.za",
                DisplayName = "Front Desk Employee"
            }
        };

        public static AppUser? Validate(string username, string password) =>
            Users.FirstOrDefault(u =>
                string.Equals(u.Username, username, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
    }
}
