using Microsoft.AspNetCore.Authentication.Cookies;
using EazzyTravels.Services;

var builder = WebApplication.CreateBuilder(args);

// Razor Pages (this is what powers the .cshtml forms)
builder.Services.AddRazorPages(options =>
{
    // Every page requires login EXCEPT the ones under /Account (Login, VerifyOtp, Logout)
    options.Conventions.AuthorizeFolder("/");
    options.Conventions.AllowAnonymousToFolder("/Account");
});

// Cookie-based authentication (username/password + email OTP happens in Pages/Account)
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/Login";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });

builder.Services.AddAuthorization();

// App services
builder.Services.AddSingleton<OtpService>();
builder.Services.AddScoped<IEmailSender, SmtpEmailSender>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();   // serves wwwroot/css/site.css etc.
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.Run();
